
# APIs:
GOOGLE_API_KEY = 'AIzaSyDJlvljO' + '-' + 'CVH5ax4paudEnj9RoERL6Xhbc'

# Distance conversions:
METERS_IN_MILE = 1609.34

# Rules:
DEFAULT_RADIUS_IN_MILES = 1.1

####################################################################################################

# Assumptions:
FEET_IN_STORY = 10
